module ComputingDepartment {
	requires java.desktop;
}